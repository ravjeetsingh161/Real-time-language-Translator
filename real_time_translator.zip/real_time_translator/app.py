from flask import Flask, render_template, request, jsonify
from deep_translator import GoogleTranslator

app = Flask(__name__)

# Supported languages dictionary
languages = {
    "English": "en",
    "Hindi": "hi",
    "Punjabi": "pa",
    "French": "fr",
    "German": "de",
    "Spanish": "es",
    "Chinese": "zh-CN",
    "Japanese": "ja",
    "Arabic": "ar",
    "Russian": "ru"
}


@app.route("/")
def index():
    return render_template("index.html", languages=languages)


@app.route("/translate", methods=["POST"])
def translate():
    data = request.get_json()
    text = data.get("text")
    target_lang = data.get("target")

    try:
        translated = GoogleTranslator(source="auto", target=target_lang).translate(text)
        return jsonify({"translated": translated})
    except Exception as e:
        return jsonify({"translated": "Error: " + str(e)})


if __name__ == "__main__":
    app.run(debug=True)